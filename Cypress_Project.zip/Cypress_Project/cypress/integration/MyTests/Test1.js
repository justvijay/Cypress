
///<reference types="Cypress" />

describe('Login', function()
{

   it('My First TC',function(){

    cy.visit('https://www.rahulshettyacademy.com/seleniumPractise')
    cy.get('.search-keyword').type('ca')    
    //cy.wait(500)
    //cy.get('.product:visible').should('have.length',4)
    cy.get('.products').find('.product').should('have.length',4)
    cy.get('.products').find('.product').eq(2).contains('ADD TO CART').click()
    cy.get('.products').find('.product').each(($e1, index, $list) => {

        const  VegName=$e1.find('h4.product-name').text()
        if(VegName.includes('Cashews')|VegName.includes('Carrot'))
        {
        $e1.find('button').click()
        }

    })    
    cy.get('.cart-icon > img').click()
    cy.contains('PROCEED TO CHECKOUT').click()
    cy.get(':nth-child(14)').click()

   })
  
})