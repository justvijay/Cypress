
///<reference types="Cypress" />

describe('Popups', function()
{

    it('Handle Popups',function(){
        
            cy.visit('https://www.rahulshettyacademy.com/AutomationPractice')
          
            cy.get('#alertbtn').click()
            cy.get('[value="Confirm"]').click()

            //Window:alert
            cy.on('window:alert',(str)=>{

                expect(str).to.equals('Hello , share this practice page and share your knowledge')
            });
            //Window:confirm
            cy.on('window:confirm',(str)=>{

            expect(str).to.equals('Hello , Are you sure you want to confirm?')

            });
             
            //Handling child tab with jQuerry

           // cy.get('#opentab').invoke('removeAttr','target').click()

            cy.url().should('include','rahulshettyacademy.com')
            cy.go('back')

            
        
        })      

   })


